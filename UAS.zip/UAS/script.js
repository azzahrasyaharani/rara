// script.js
function getData() {
    const searchInput = document.getElementById('searchInput').value;
    const apiUrl = `https://api.example.com/data?search=${searchInput}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => displayData(data))
        .catch(error => console.error('Error:', error));
}

function displayData(data) {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = '';

    if (data.length === 0) {
        resultDiv.innerHTML = '<p>No data found.</p>';
        return;
    }

    const ulElement = document.createElement('ul');
    ulElement.className = 'list-group';

    data.forEach(item => {
        const liElement = document.createElement('li');
        liElement.className = 'list-group-item';
        liElement.textContent = item.name; // Assuming the API returns an object with a 'name' property
        ulElement.appendChild(liElement);
    });

    resultDiv.appendChild(ulElement);
}
