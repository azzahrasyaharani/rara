// script.js
const progress = document.getElementById('progress');
const circles = document.querySelectorAll('.circle');

let currentActive = 1;

function updateProgress() {
    const activeCircles = document.querySelectorAll('.circle.active');

    progress.style.width = ((activeCircles.length - 1) / (circles.length - 1)) * 100 + '%';
}

function setProgress(step) {
    if (step < 1 || step > circles.length) {
        return;
    }

    circles.forEach((circle, index) => {
        if (index < step) {
            circle.classList.add('active');
        } else {
            circle.classList.remove('active');
        }
    });

    currentActive = step;
    updateProgress();
}
